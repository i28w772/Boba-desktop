import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import TitleBar from './components/TitleBar.jsx'
import Dock from './components/Dock.jsx'
import WeatherWidget from './components/WeatherWidget.jsx'
import ClockWidget from './components/ClockWidget.jsx'
import HardwareMonitor from './components/HardwareMonitor.jsx'
import DeviceInfo from './components/DeviceInfo.jsx'
import InstallPrompt from './components/InstallPrompt.jsx'
import ArcadeSection from './components/ArcadeSection.jsx'
import LoginScreen from './components/LoginScreen.jsx'
import BobaLogo from './components/BobaLogo.jsx'
import LoadingSpinner from './components/LoadingSpinner.jsx'
import soundManager from './utils/soundManager.js'
import { useInstallPrompt } from './utils/useInstallPrompt.js'

const WINDOW_STATES = {
  NORMAL: 'normal',
  MAXIMIZED: 'maximized',
  MINIMIZED: 'minimized',
  CLOSED: 'closed',
}

const USER_STORAGE_KEY = 'bobaos_user'

function greeting(name) {
  const hour = new Date().getHours()
  const part = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening'
  return `Good ${part}, ${name} 🧋`
}

export default function App() {
  const [windowState, setWindowState] = useState(WINDOW_STATES.NORMAL)
  const [muted, setMuted] = useState(false)
  const [booting, setBooting] = useState(true)
  const [user, setUser] = useState(null)
  const [userLoaded, setUserLoaded] = useState(false)
  const [installBannerForceOpen, setInstallBannerForceOpen] = useState(false)
  const installState = useInstallPrompt()

  // Load saved username on first mount, and auto-fill the window on
  // compact / iPad-sized screens so the dashboard isn't cramped.
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(USER_STORAGE_KEY)
      if (saved) setUser(JSON.parse(saved))
    } catch (e) {
      // ignore malformed storage
    }
    setUserLoaded(true)

    if (window.innerWidth <= 900 || window.innerHeight <= 520) {
      setWindowState(WINDOW_STATES.MAXIMIZED)
    }
  }, [])

  useEffect(() => {
    const t = setTimeout(() => setBooting(false), 1400)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    soundManager.setMuted(muted)
  }, [muted])

  const minimize = () => {
    soundManager.minimize()
    setWindowState(WINDOW_STATES.MINIMIZED)
  }

  const restore = () => {
    setWindowState(WINDOW_STATES.NORMAL)
  }

  const toggleMaximize = () => {
    soundManager.maximize()
    setWindowState((s) => (s === WINDOW_STATES.MAXIMIZED ? WINDOW_STATES.NORMAL : WINDOW_STATES.MAXIMIZED))
  }

  const close = () => {
    soundManager.close()
    setWindowState(WINDOW_STATES.CLOSED)
  }

  const reopen = () => {
    soundManager.maximize()
    setWindowState(WINDOW_STATES.NORMAL)
  }

  const handleLogin = (newUser) => {
    setUser(newUser)
    try {
      window.localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(newUser))
    } catch (e) {
      // storage may be unavailable (e.g. private browsing) — app still works
    }
  }

  const handleSwitchUser = () => {
    soundManager.hover()
    setUser(null)
    try {
      window.localStorage.removeItem(USER_STORAGE_KEY)
    } catch (e) {
      // ignore
    }
  }

  const handleInstallClick = async () => {
    if (installState.canInstall) {
      await installState.promptInstall()
    } else {
      // No native prompt available (iOS Safari, or an unsupported desktop
      // browser) — surface the banner with the right instructions instead.
      setInstallBannerForceOpen(true)
    }
  }

  const maximized = windowState === WINDOW_STATES.MAXIMIZED
  const minimized = windowState === WINDOW_STATES.MINIMIZED
  const closed = windowState === WINDOW_STATES.CLOSED

  return (
    <div className="safe-area relative h-[100dvh] w-screen overflow-hidden flex items-center justify-center p-3 sm:p-6">
      {/* ambient background blobs */}
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-taro/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-matcha/30 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 right-1/4 h-40 w-40 rounded-full bg-blush/40 blur-3xl" />

      <AnimatePresence mode="wait">
        {closed && (
          <motion.div
            key="closed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-4 text-center px-4"
          >
            <BobaLogo size={56} />
            <p className="font-display text-lg text-pearl font-semibold">The shop is closed for now ☕</p>
            <p className="text-sm text-pearl/60 max-w-xs">Thanks for stopping by BobaOS. Come back anytime for another cup.</p>
            <button
              onClick={reopen}
              className="mt-2 px-5 py-2.5 rounded-full bg-taro text-white font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
            >
              Reopen the shop
            </button>
          </motion.div>
        )}

        {!closed && (
          <motion.div
            key="window"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{
              opacity: minimized ? 0 : 1,
              scale: minimized ? 0.4 : 1,
              y: minimized ? 420 : 0,
              width: maximized ? '100%' : 960,
              height: maximized ? '100%' : 640,
            }}
            transition={{ type: 'spring', stiffness: 220, damping: 26 }}
            style={{ pointerEvents: minimized ? 'none' : 'auto' }}
            className="flex flex-col rounded-2xl overflow-hidden shadow-soft glow-border max-w-full max-h-full"
          >
            <TitleBar
              onMinimize={minimize}
              onMaximize={toggleMaximize}
              onClose={close}
              maximized={maximized}
              muted={muted}
              onToggleMute={() => setMuted((m) => !m)}
              user={user}
              onSwitchUser={handleSwitchUser}
              installState={installState}
              onInstallClick={handleInstallClick}
            />

            {!booting && userLoaded && user && (
              <InstallPrompt
                {...installState}
                forceOpen={installBannerForceOpen}
                onForceOpenHandled={() => setInstallBannerForceOpen(false)}
              />
            )}

            <div className="flex-1 overflow-y-auto overscroll-contain bg-gradient-to-br from-cream via-milk/40 to-cream px-4 sm:px-6 py-5 sm:py-6">
              {booting || !userLoaded ? (
                <div className="h-full w-full flex flex-col items-center justify-center gap-4">
                  <LoadingSpinner size={56} label="Steeping your dashboard…" />
                </div>
              ) : !user ? (
                <div className="h-full w-full flex items-center justify-center">
                  <AnimatePresence mode="wait">
                    <LoginScreen key="login" onSubmit={handleLogin} />
                  </AnimatePresence>
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                >
                  <p className="font-display text-sm text-pearl/70 mb-4">{greeting(user.name)}</p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-5">
                    <div className="h-60"><WeatherWidget /></div>
                    <div className="h-60"><ClockWidget /></div>
                    <div className="h-60"><HardwareMonitor /></div>
                    <div className="h-60"><DeviceInfo /></div>
                  </div>

                  <div className="mt-4 sm:mt-5">
                    <ArcadeSection />
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Dock minimized={minimized} onRestore={restore} />
    </div>
  )
}
