import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import soundManager from '../utils/soundManager.js'
import { AVATAR_COLORS } from './LoginScreen.jsx'

const COLOR_HEX = AVATAR_COLORS.reduce((acc, c) => ({ ...acc, [c.id]: c.hex }), {})

export default function ProfileMenu({ user, onSwitchUser }) {
  const [open, setOpen] = useState(false)
  if (!user) return null

  return (
    <div className="relative">
      <button
        onClick={() => {
          soundManager.hover()
          setOpen((o) => !o)
        }}
        className="flex items-center gap-1.5 pl-1 pr-2.5 py-1 rounded-full hover:bg-white/50 transition-colors"
      >
        <span
          className="h-5 w-5 rounded-full border border-white/60 shrink-0"
          style={{ background: COLOR_HEX[user.color] || COLOR_HEX.matcha }}
        />
        <span className="text-xs font-semibold text-pearl/80 max-w-[84px] truncate">{user.name}</span>
      </button>

      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: -6, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.95 }}
              className="absolute right-0 mt-2 w-40 glass rounded-xl p-1.5 shadow-soft z-50"
            >
              <button
                onClick={() => {
                  soundManager.click()
                  setOpen(false)
                  onSwitchUser()
                }}
                className="w-full text-left text-xs px-2.5 py-2 rounded-lg hover:bg-white/60 text-pearl/80 transition-colors"
              >
                Switch user
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
