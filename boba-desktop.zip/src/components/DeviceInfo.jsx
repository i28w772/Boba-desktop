import { useEffect, useState } from 'react'
import { Tablet, Smartphone, Monitor, MousePointer2, Hand } from 'lucide-react'
import { detectDevice } from '../utils/device.js'

function iconFor(deviceType) {
  if (deviceType === 'iPad' || deviceType === 'Android Tablet' || deviceType === 'Touch Tablet') return Tablet
  if (deviceType === 'iPhone' || deviceType === 'Android Phone') return Smartphone
  return Monitor
}

export default function DeviceInfo() {
  const [info, setInfo] = useState(() => detectDevice())

  useEffect(() => {
    const onChange = () => setInfo(detectDevice())
    window.addEventListener('resize', onChange)
    window.addEventListener('orientationchange', onChange)
    return () => {
      window.removeEventListener('resize', onChange)
      window.removeEventListener('orientationchange', onChange)
    }
  }, [])

  const Icon = iconFor(info.deviceType)

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5 mb-3">
        <Icon size={14} className="text-taro-dark" /> About This Café
      </h3>
      <div className="flex items-center gap-3 mb-3">
        <div className="p-3 rounded-2xl bg-milk/60">
          <Icon size={28} className="text-taro-dark" strokeWidth={1.7} />
        </div>
        <div>
          <p className="font-display text-base font-semibold text-pearl leading-none">{info.deviceType}</p>
          <p className="text-xs text-pearl/60 mt-1">{info.os} · {info.browser}</p>
        </div>
      </div>
      <div className="mt-auto grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs text-pearl/70">
        <span className="flex items-center gap-1.5">
          {info.isTouch ? <Hand size={12} /> : <MousePointer2 size={12} />}
          {info.isTouch ? 'Touch input' : 'Mouse input'}
        </span>
        <span>{info.orientation}</span>
        <span>{info.width}×{info.height}px</span>
        <span>@{info.pixelRatio}x display</span>
      </div>
    </div>
  )
}
