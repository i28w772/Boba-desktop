import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Cpu, MemoryStick, Gauge } from 'lucide-react'

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v))
}

function useSimulatedMetric(base, volatility) {
  const [value, setValue] = useState(base)
  const ref = useRef(value)
  useEffect(() => {
    const id = setInterval(() => {
      const drift = (Math.random() - 0.5) * volatility
      const next = clamp(ref.current + drift, 6, 96)
      ref.current = next
      setValue(next)
    }, 1400)
    return () => clearInterval(id)
  }, [volatility])
  return value
}

function Tank({ label, value, color, Icon, unit = '%' }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative h-32 w-14 rounded-full overflow-hidden border-2 border-pearl/70 bg-cream shadow-inner">
        <motion.div
          className="absolute bottom-0 left-0 right-0"
          style={{ background: color }}
          animate={{ height: `${value}%` }}
          transition={{ duration: 1.1, ease: 'easeInOut' }}
        >
          <div className="w-full h-2 shimmer-bg animate-shimmer opacity-60" />
          {/* boba pearls floating inside the tank */}
          <span className="absolute left-2 bottom-3 h-2 w-2 rounded-full bg-pearl/70 animate-wobble" />
          <span className="absolute right-2 bottom-6 h-1.5 w-1.5 rounded-full bg-pearl/60 animate-wobble" style={{ animationDelay: '0.4s' }} />
          <span className="absolute left-4 bottom-9 h-1.5 w-1.5 rounded-full bg-pearl/50 animate-wobble" style={{ animationDelay: '0.9s' }} />
        </motion.div>
        <div className="absolute inset-x-0 top-1 flex justify-center text-pearl/50">
          <Icon size={14} />
        </div>
      </div>
      <span className="text-xs font-semibold text-pearl">{label}</span>
      <span className="font-mono text-xs text-pearl/60">{Math.round(value)}{unit}</span>
    </div>
  )
}

export default function HardwareMonitor() {
  const cpu = useSimulatedMetric(38, 22)
  const gpu = useSimulatedMetric(52, 26)
  const ram = useSimulatedMetric(61, 12)

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5 mb-4">
        <Gauge size={14} className="text-taro-dark" /> Boba Tank Levels
      </h3>
      <div className="flex-1 flex items-center justify-around">
        <Tank label="CPU" value={cpu} color="linear-gradient(180deg,#D9B98A,#B39CD0)" Icon={Cpu} />
        <Tank label="GPU" value={gpu} color="linear-gradient(180deg,#C9E0C0,#8CA779)" Icon={Gauge} />
        <Tank label="RAM" value={ram} color="linear-gradient(180deg,#F3C9D4,#B39CD0)" Icon={MemoryStick} />
      </div>
      <p className="text-[11px] text-pearl/45 text-center mt-3">Simulated readings, refilled every couple seconds ☕</p>
    </div>
  )
}
