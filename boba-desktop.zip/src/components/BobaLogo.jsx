import { motion } from 'framer-motion'

export default function BobaLogo({ size = 32, spin = false }) {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <motion.svg
        viewBox="0 0 64 64"
        width={size}
        height={size}
        animate={spin ? { rotate: 360 } : { rotate: [0, -4, 4, 0] }}
        transition={
          spin
            ? { duration: 1.1, repeat: Infinity, ease: 'linear' }
            : { duration: 3.5, repeat: Infinity, ease: 'easeInOut' }
        }
      >
        {/* Cup body */}
        <path
          d="M14 22 L18 58 Q32 62 46 58 L50 22 Z"
          fill="#F7E9D3"
          stroke="#4A3324"
          strokeWidth="2"
        />
        {/* Milk tea liquid */}
        <path d="M16.5 28 L19.5 54 Q32 57 44.5 54 L47.5 28 Z" fill="#D9B98A" />
        {/* Pearls */}
        <circle cx="24" cy="50" r="2.6" fill="#4A3324" />
        <circle cx="32" cy="53" r="2.6" fill="#4A3324" />
        <circle cx="40" cy="49" r="2.6" fill="#4A3324" />
        <circle cx="28" cy="45" r="2.6" fill="#4A3324" />
        <circle cx="36" cy="44" r="2.6" fill="#4A3324" />
        {/* Dome lid */}
        <path d="M12 22 Q32 10 52 22 L50 26 L14 26 Z" fill="#B39CD0" stroke="#4A3324" strokeWidth="2" />
        {/* Straw */}
        <rect x="30" y="2" width="5" height="24" rx="1.5" fill="#8CA779" stroke="#4A3324" strokeWidth="1.5" transform="rotate(8 32 14)" />
      </motion.svg>
    </div>
  )
}
