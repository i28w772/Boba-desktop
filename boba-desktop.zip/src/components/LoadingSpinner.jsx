import { motion } from 'framer-motion'

export default function LoadingSpinner({ size = 48, label }) {
  const pearls = [0, 1, 2, 3, 4]
  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative" style={{ width: size, height: size }}>
        {pearls.map((i) => {
          const angle = (i / pearls.length) * 2 * Math.PI
          const radius = size / 2 - 6
          const x = Math.cos(angle) * radius
          const y = Math.sin(angle) * radius
          return (
            <motion.span
              key={i}
              className="absolute rounded-full bg-pearl"
              style={{
                width: size * 0.22,
                height: size * 0.22,
                left: size / 2 - (size * 0.22) / 2 + x,
                top: size / 2 - (size * 0.22) / 2 + y,
              }}
              animate={{ scale: [0.7, 1, 0.7], opacity: [0.5, 1, 0.5] }}
              transition={{
                duration: 1.1,
                repeat: Infinity,
                delay: i * 0.13,
                ease: 'easeInOut',
              }}
            />
          )
        })}
      </div>
      {label && <span className="text-xs font-medium text-pearl/70 font-body">{label}</span>}
    </div>
  )
}
