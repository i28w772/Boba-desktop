import { useEffect, useState } from 'react'
import { Clock as ClockIcon } from 'lucide-react'

function AnalogFace({ date }) {
  const seconds = date.getSeconds()
  const minutes = date.getMinutes()
  const hours = date.getHours() % 12

  const secDeg = seconds * 6
  const minDeg = minutes * 6 + seconds * 0.1
  const hourDeg = hours * 30 + minutes * 0.5

  const ticks = Array.from({ length: 12 })

  return (
    <svg viewBox="0 0 120 120" className="w-28 h-28">
      <circle cx="60" cy="60" r="56" fill="#FBF2E4" stroke="#4A3324" strokeWidth="2" />
      {ticks.map((_, i) => {
        const angle = (i / 12) * 2 * Math.PI
        const x1 = 60 + Math.sin(angle) * 48
        const y1 = 60 - Math.cos(angle) * 48
        const x2 = 60 + Math.sin(angle) * 42
        const y2 = 60 - Math.cos(angle) * 42
        return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#8CA779" strokeWidth="2.5" strokeLinecap="round" />
      })}
      {/* Hour hand */}
      <line
        x1="60" y1="60"
        x2={60 + Math.sin((hourDeg * Math.PI) / 180) * 26}
        y2={60 - Math.cos((hourDeg * Math.PI) / 180) * 26}
        stroke="#4A3324" strokeWidth="4" strokeLinecap="round"
      />
      {/* Minute hand */}
      <line
        x1="60" y1="60"
        x2={60 + Math.sin((minDeg * Math.PI) / 180) * 38}
        y2={60 - Math.cos((minDeg * Math.PI) / 180) * 38}
        stroke="#4A3324" strokeWidth="3" strokeLinecap="round"
      />
      {/* Second hand — taro colored */}
      <line
        x1="60" y1="60"
        x2={60 + Math.sin((secDeg * Math.PI) / 180) * 42}
        y2={60 - Math.cos((secDeg * Math.PI) / 180) * 42}
        stroke="#B39CD0" strokeWidth="1.5" strokeLinecap="round"
      />
      <circle cx="60" cy="60" r="3.5" fill="#4A3324" />
      <text x="60" y="22" textAnchor="middle" fontSize="9" fill="#4A3324" fontFamily="Fredoka">🧋</text>
    </svg>
  )
}

export default function ClockWidget() {
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  const dateStr = now.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5 mb-3">
        <ClockIcon size={14} className="text-taro-dark" /> Café Timer
      </h3>
      <div className="flex-1 flex items-center gap-5">
        <AnalogFace date={now} />
        <div className="flex flex-col">
          <span className="font-mono text-2xl font-semibold text-pearl tracking-tight">{timeStr}</span>
          <span className="text-xs text-pearl/60 mt-1">{dateStr}</span>
          <div className="mt-3 grid grid-cols-7 gap-1 text-[10px] text-pearl/50">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
              <span
                key={i}
                className={`h-4 w-4 flex items-center justify-center rounded-full ${
                  i === now.getDay() ? 'bg-matcha text-white font-semibold' : ''
                }`}
              >
                {d}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
