import { useCallback, useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { RotateCcw } from 'lucide-react'
import soundManager from '../../utils/soundManager.js'

const SIZE = 4
const BOARD_SIZE = 320
const FLAVORS = {
  2: { name: 'Water', emoji: '💧', bg: '#F7F2E8' },
  4: { name: 'Milk Tea', emoji: '🥛', bg: '#EEDFC2' },
  8: { name: 'Taro', emoji: '🟣', bg: '#D8C9E9' },
  16: { name: 'Matcha', emoji: '🍵', bg: '#B7CBA3' },
  32: { name: 'Thai Tea', emoji: '🧡', bg: '#F0B99B' },
  64: { name: 'Brown Sugar', emoji: '🟤', bg: '#C79A6B' },
  128: { name: 'Wintermelon', emoji: '🍈', bg: '#A9D1A3' },
  256: { name: 'Mango', emoji: '🥭', bg: '#F4C04E' },
  512: { name: 'Honeydew', emoji: '🍈', bg: '#CDE896' },
  1024: { name: 'Golden Pearl', emoji: '✨', bg: '#F3D67A' },
  2048: { name: 'Legendary Boba', emoji: '🧋', bg: '#B39CD0' },
}

function emptyGrid() {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(0))
}

function cloneGrid(g) {
  return g.map((row) => [...row])
}

function addRandomTile(grid) {
  const empties = []
  grid.forEach((row, r) => row.forEach((v, c) => v === 0 && empties.push([r, c])))
  if (empties.length === 0) return grid
  const [r, c] = empties[Math.floor(Math.random() * empties.length)]
  const next = cloneGrid(grid)
  next[r][c] = Math.random() < 0.9 ? 2 : 4
  return next
}

function transpose(grid) {
  return grid[0].map((_, c) => grid.map((row) => row[c]))
}

function reverseRows(grid) {
  return grid.map((row) => [...row].reverse())
}

function slideAndMergeRow(row, onScore) {
  const filtered = row.filter((v) => v !== 0)
  const result = []
  let merged = false
  for (let i = 0; i < filtered.length; i++) {
    if (filtered[i] === filtered[i + 1]) {
      const value = filtered[i] * 2
      result.push(value)
      onScore(value)
      merged = true
      i++
    } else {
      result.push(filtered[i])
    }
  }
  while (result.length < SIZE) result.push(0)
  return { row: result, merged: merged || row.join(',') !== result.join(',') }
}

function move(grid, direction, onScore) {
  let working = grid
  let didTranspose = false
  let didReverse = false

  if (direction === 'up' || direction === 'down') {
    working = transpose(working)
    didTranspose = true
  }
  if (direction === 'right' || direction === 'down') {
    working = reverseRows(working)
    didReverse = true
  }

  let changed = false
  const newRows = working.map((row) => {
    const { row: r, merged } = slideAndMergeRow(row, onScore)
    if (merged) changed = true
    return r
  })

  let result = newRows
  if (didReverse) result = reverseRows(result)
  if (didTranspose) result = transpose(result)

  return { grid: result, changed }
}

function canMove(grid) {
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (grid[r][c] === 0) return true
      if (c < SIZE - 1 && grid[r][c] === grid[r][c + 1]) return true
      if (r < SIZE - 1 && grid[r][c] === grid[r + 1][c]) return true
    }
  }
  return false
}

export default function TeaMerge2048({ maxWidth }) {
  const scale = Math.max(0.6, Math.min(1, (maxWidth || BOARD_SIZE) / BOARD_SIZE))
  const [grid, setGrid] = useState(() => addRandomTile(addRandomTile(emptyGrid())))
  const [score, setScore] = useState(0)
  const [best, setBest] = useState(0)
  const [gameOver, setGameOver] = useState(false)
  const [won, setWon] = useState(false)
  const containerRef = useRef(null)

  const reset = () => {
    soundManager.click()
    setGrid(addRandomTile(addRandomTile(emptyGrid())))
    setScore(0)
    setGameOver(false)
    setWon(false)
  }

  const handleMove = useCallback(
    (direction) => {
      if (gameOver) return
      let gained = 0
      const { grid: moved, changed } = move(grid, direction, (v) => {
        gained += v
        if (v >= 2048) setWon(true)
      })
      if (!changed) return
      const withTile = addRandomTile(moved)
      setGrid(withTile)
      if (gained > 0) {
        setScore((s) => s + gained)
        soundManager.success()
      } else {
        soundManager.hover()
      }
      if (!canMove(withTile)) {
        setGameOver(true)
        soundManager.error()
      }
    },
    [grid, gameOver]
  )

  useEffect(() => {
    if (score > best) setBest(score)
  }, [score, best])

  useEffect(() => {
    const onKey = (e) => {
      const map = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' }
      if (map[e.key]) {
        e.preventDefault()
        handleMove(map[e.key])
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [handleMove])

  // basic swipe support
  const touchStart = useRef(null)
  const onTouchStart = (e) => (touchStart.current = e.touches[0])
  const onTouchEnd = (e) => {
    if (!touchStart.current) return
    const dx = e.changedTouches[0].clientX - touchStart.current.clientX
    const dy = e.changedTouches[0].clientY - touchStart.current.clientY
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return
    if (Math.abs(dx) > Math.abs(dy)) handleMove(dx > 0 ? 'right' : 'left')
    else handleMove(dy > 0 ? 'down' : 'up')
    touchStart.current = null
  }

  return (
    <div className="flex flex-col items-center" ref={containerRef} tabIndex={0}>
      <div className="flex items-center justify-between w-full max-w-[320px] mb-2 text-xs font-mono text-pearl/70">
        <span>Score: {score}</span>
        <span>Best: {best}</span>
        <button
          onClick={reset}
          className="flex items-center gap-1 px-2 py-1 rounded-full bg-white/50 hover:bg-white/70 transition"
        >
          <RotateCcw size={12} /> Reset
        </button>
      </div>

      <div
        className="relative mx-auto touch-none"
        style={{ width: BOARD_SIZE * scale, height: BOARD_SIZE * scale }}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
      <div
        className="relative rounded-2xl border-2 border-milk-dark bg-milk/50 p-2"
        style={{ width: BOARD_SIZE, height: BOARD_SIZE, transform: `scale(${scale})`, transformOrigin: 'top left' }}
      >
        <div className="grid grid-cols-4 grid-rows-4 gap-2 w-full h-full">
          {grid.map((row, r) =>
            row.map((v, c) => (
              <div key={`${r}-${c}`} className="rounded-xl bg-cream/70 flex items-center justify-center" />
            ))
          )}
        </div>

        <div className="absolute inset-2 grid grid-cols-4 grid-rows-4 gap-2 pointer-events-none">
          {grid.map((row, r) =>
            row.map((v, c) => {
              if (!v) return <div key={`${r}-${c}`} />
              const info = FLAVORS[v] || FLAVORS[2048]
              return (
                <div key={`${r}-${c}`} className="relative flex items-center justify-center">
                  <AnimatePresence>
                    <motion.div
                      key={`${r}-${c}-${v}`}
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                      className="w-full h-full rounded-xl flex flex-col items-center justify-center shadow-soft border border-white/50"
                      style={{ background: info.bg }}
                    >
                      <span className="text-lg leading-none">{info.emoji}</span>
                      <span className="text-[9px] font-semibold text-pearl/80 mt-0.5 leading-none text-center px-1">
                        {info.name}
                      </span>
                    </motion.div>
                  </AnimatePresence>
                </div>
              )
            })
          )}
        </div>

        {(gameOver || won) && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-cream/85 backdrop-blur-sm rounded-2xl">
            <p className="font-display text-pearl font-semibold text-sm text-center px-6">
              {won ? '🧋 You brewed the Legendary Boba!' : 'No more moves — the cup is full!'}
            </p>
            <button
              onClick={reset}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-taro text-white text-sm font-semibold shadow-soft hover:brightness-105 active:scale-95 transition"
            >
              <RotateCcw size={14} /> Brew again
            </button>
          </div>
        )}
      </div>
      </div>
      <p className="text-[11px] text-pearl/50 mt-2 text-center px-4">Arrow keys or swipe to combine matching flavors</p>
    </div>
  )
}
