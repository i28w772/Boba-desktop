import { useEffect, useRef, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Play, RotateCcw } from 'lucide-react'
import soundManager from '../../utils/soundManager.js'

const GAME_WIDTH = 320
const GAME_HEIGHT = 340
const CUP_WIDTH = 56
const ROUND_SECONDS = 30

function randomId() {
  return Math.random().toString(36).slice(2)
}

export default function CatchBobaGame({ maxWidth }) {
  const scale = Math.max(0.6, Math.min(1, (maxWidth || GAME_WIDTH) / GAME_WIDTH))
  const [running, setRunning] = useState(false)
  const [cupX, setCupX] = useState(GAME_WIDTH / 2 - CUP_WIDTH / 2)
  const [pearls, setPearls] = useState([])
  const [score, setScore] = useState(0)
  const [misses, setMisses] = useState(0)
  const [timeLeft, setTimeLeft] = useState(ROUND_SECONDS)
  const [best, setBest] = useState(0)
  const areaRef = useRef(null)
  const rafRef = useRef(null)
  const spawnRef = useRef(null)
  const timerRef = useRef(null)

  const reset = () => {
    setPearls([])
    setScore(0)
    setMisses(0)
    setTimeLeft(ROUND_SECONDS)
    setCupX(GAME_WIDTH / 2 - CUP_WIDTH / 2)
  }

  const start = () => {
    soundManager.click()
    reset()
    setRunning(true)
  }

  const handleMove = useCallback(
    (clientX) => {
      if (!areaRef.current) return
      const rect = areaRef.current.getBoundingClientRect()
      const x = (clientX - rect.left) / scale - CUP_WIDTH / 2
      setCupX(Math.max(0, Math.min(GAME_WIDTH - CUP_WIDTH, x)))
    },
    [scale]
  )

  useEffect(() => {
    if (!running) return
    const onMouseMove = (e) => handleMove(e.clientX)
    const onTouchMove = (e) => e.touches[0] && handleMove(e.touches[0].clientX)
    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('touchmove', onTouchMove)
    return () => {
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('touchmove', onTouchMove)
    }
  }, [running, handleMove])

  useEffect(() => {
    if (!running) return
    const onKey = (e) => {
      setCupX((x) => {
        if (e.key === 'ArrowLeft') return Math.max(0, x - 24)
        if (e.key === 'ArrowRight') return Math.min(GAME_WIDTH - CUP_WIDTH, x + 24)
        return x
      })
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [running])

  // spawn pearls
  useEffect(() => {
    if (!running) return
    spawnRef.current = setInterval(() => {
      setPearls((p) => [
        ...p,
        {
          id: randomId(),
          x: Math.random() * (GAME_WIDTH - 20),
          y: -20,
          speed: 1.6 + Math.random() * 2.2,
          flavor: Math.random() > 0.15 ? '🟤' : '✨',
          bonus: Math.random() > 0.85,
        },
      ])
    }, 550)
    return () => clearInterval(spawnRef.current)
  }, [running])

  // game loop
  useEffect(() => {
    if (!running) return
    const loop = () => {
      setPearls((prev) => {
        const next = []
        for (const pearl of prev) {
          const ny = pearl.y + pearl.speed * 3
          const caught =
            ny > GAME_HEIGHT - 46 &&
            ny < GAME_HEIGHT &&
            pearl.x + 10 > cupX &&
            pearl.x < cupX + CUP_WIDTH
          if (caught) {
            soundManager.click()
            setScore((s) => s + (pearl.bonus ? 5 : 1))
            continue
          }
          if (ny > GAME_HEIGHT) {
            setMisses((m) => m + 1)
            soundManager.error()
            continue
          }
          next.push({ ...pearl, y: ny })
        }
        return next
      })
      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(rafRef.current)
  }, [running, cupX])

  // timer
  useEffect(() => {
    if (!running) return
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timerRef.current)
          setRunning(false)
          soundManager.success()
          return 0
        }
        return t - 1
      })
    }, 1000)
    return () => clearInterval(timerRef.current)
  }, [running])

  useEffect(() => {
    if (!running && score > best) setBest(score)
  }, [running, score, best])

  return (
    <div className="flex flex-col items-center">
      <div className="flex items-center justify-between w-full max-w-[320px] mb-2 text-xs font-mono text-pearl/70">
        <span>Score: {score}</span>
        <span>⏱ {timeLeft}s</span>
        <span>Best: {best}</span>
      </div>
      <div className="relative mx-auto" style={{ width: GAME_WIDTH * scale, height: GAME_HEIGHT * scale }}>
        <div
          ref={areaRef}
          className="relative overflow-hidden rounded-2xl border-2 border-milk-dark bg-gradient-to-b from-cream to-milk/60 touch-none"
          style={{ width: GAME_WIDTH, height: GAME_HEIGHT, transform: `scale(${scale})`, transformOrigin: 'top left' }}
        >
          {pearls.map((p) => (
            <span
              key={p.id}
              className="absolute text-lg select-none"
              style={{ left: p.x, top: p.y, transform: p.bonus ? 'scale(1.3)' : 'scale(1)' }}
            >
              {p.flavor}
            </span>
          ))}

          {/* cup */}
          <div
            className="absolute bottom-1 flex items-end justify-center"
            style={{ left: cupX, width: CUP_WIDTH, height: 44 }}
          >
            <span className="text-4xl leading-none select-none">🧋</span>
          </div>

          {!running && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-cream/80 backdrop-blur-sm">
              <p className="font-display text-pearl font-semibold text-sm text-center px-4">
                {timeLeft === 0 ? `Round over — ${score} pearls caught!` : 'Catch the Boba'}
              </p>
              <button
                onClick={start}
                className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-matcha text-white text-sm font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
              >
                {timeLeft === 0 && timeLeft !== ROUND_SECONDS ? <RotateCcw size={14} /> : <Play size={14} />}
                {timeLeft === ROUND_SECONDS ? 'Start' : 'Play again'}
              </button>
              <p className="text-[11px] text-pearl/50 text-center px-4">Drag, or use ← → keys, to steer the cup</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
