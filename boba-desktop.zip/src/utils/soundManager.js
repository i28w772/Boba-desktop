// soundManager.js
// A tiny procedural sound engine built on the Web Audio API.
// Every "pop" here is synthesized on the fly — no external audio files.

class SoundManager {
  constructor() {
    this.ctx = null
    this.muted = false
    this.masterGain = null
  }

  _ensureContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext
      this.ctx = new AudioCtx()
      this.masterGain = this.ctx.createGain()
      this.masterGain.gain.value = 0.35
      this.masterGain.connect(this.ctx.destination)
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume()
    }
    return this.ctx
  }

  setMuted(muted) {
    this.muted = muted
  }

  setVolume(v) {
    this._ensureContext()
    this.masterGain.gain.value = v
  }

  /**
   * A single synthesized "bubble pop": a short sine blip with a fast pitch
   * drop, layered with a burst of filtered noise for the "pop" transient.
   */
  _pop({ startFreq = 900, endFreq = 260, duration = 0.11, volume = 1, delay = 0 } = {}) {
    if (this.muted) return
    const ctx = this._ensureContext()
    const t0 = ctx.currentTime + delay

    // Tonal body of the pop
    const osc = ctx.createOscillator()
    osc.type = 'sine'
    osc.frequency.setValueAtTime(startFreq, t0)
    osc.frequency.exponentialRampToValueAtTime(Math.max(endFreq, 40), t0 + duration)

    const oscGain = ctx.createGain()
    oscGain.gain.setValueAtTime(0.0001, t0)
    oscGain.gain.exponentialRampToValueAtTime(0.9 * volume, t0 + 0.008)
    oscGain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration)

    osc.connect(oscGain)
    oscGain.connect(this.masterGain)

    // Noise transient for the "pop" click
    const bufferSize = Math.floor(ctx.sampleRate * 0.02)
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate)
    const data = buffer.getChannelData(0)
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize)
    }
    const noise = ctx.createBufferSource()
    noise.buffer = buffer

    const noiseFilter = ctx.createBiquadFilter()
    noiseFilter.type = 'bandpass'
    noiseFilter.frequency.value = startFreq * 1.4
    noiseFilter.Q.value = 1.2

    const noiseGain = ctx.createGain()
    noiseGain.gain.setValueAtTime(0.5 * volume, t0)
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.03)

    noise.connect(noiseFilter)
    noiseFilter.connect(noiseGain)
    noiseGain.connect(this.masterGain)

    osc.start(t0)
    osc.stop(t0 + duration + 0.02)
    noise.start(t0)
    noise.stop(t0 + 0.03)
  }

  /** Standard crisp click — a bright, quick bubble pop. */
  click() {
    this._pop({ startFreq: 1100, endFreq: 480, duration: 0.09, volume: 0.85 })
  }

  /** Softer pop for hovers / toggles. */
  hover() {
    this._pop({ startFreq: 1400, endFreq: 900, duration: 0.05, volume: 0.35 })
  }

  /** Two distinct sequential pops — two pearls dropping into the cup. */
  minimize() {
    this._pop({ startFreq: 950, endFreq: 420, duration: 0.1, volume: 0.9, delay: 0 })
    this._pop({ startFreq: 820, endFreq: 340, duration: 0.11, volume: 0.9, delay: 0.16 })
  }

  /** A cheerful rising pop pair for maximize / restore. */
  maximize() {
    this._pop({ startFreq: 500, endFreq: 1200, duration: 0.12, volume: 0.85 })
  }

  /** A descending, soft "sad pop" — shutting the shop for the night. */
  close() {
    if (this.muted) return
    const ctx = this._ensureContext()
    const t0 = ctx.currentTime

    const osc = ctx.createOscillator()
    osc.type = 'sine'
    osc.frequency.setValueAtTime(700, t0)
    osc.frequency.exponentialRampToValueAtTime(120, t0 + 0.45)

    const gain = ctx.createGain()
    gain.gain.setValueAtTime(0.0001, t0)
    gain.gain.exponentialRampToValueAtTime(0.7, t0 + 0.03)
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.5)

    osc.connect(gain)
    gain.connect(this.masterGain)
    osc.start(t0)
    osc.stop(t0 + 0.52)
  }

  /** A pleasant success chime — used for game wins / merges. */
  success() {
    this._pop({ startFreq: 700, endFreq: 1100, duration: 0.08, volume: 0.7, delay: 0 })
    this._pop({ startFreq: 900, endFreq: 1500, duration: 0.09, volume: 0.7, delay: 0.09 })
  }

  /** A small negative buzz — used for game-over / mismatches. */
  error() {
    if (this.muted) return
    const ctx = this._ensureContext()
    const t0 = ctx.currentTime
    const osc = ctx.createOscillator()
    osc.type = 'square'
    osc.frequency.setValueAtTime(180, t0)
    osc.frequency.linearRampToValueAtTime(90, t0 + 0.2)
    const gain = ctx.createGain()
    gain.gain.setValueAtTime(0.15, t0)
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.22)
    osc.connect(gain)
    gain.connect(this.masterGain)
    osc.start(t0)
    osc.stop(t0 + 0.23)
  }
}

const soundManager = new SoundManager()
export default soundManager
