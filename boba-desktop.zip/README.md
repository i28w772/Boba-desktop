# BobaOS — Boba Tea Desktop Dashboard

A cozy, premium "desktop app"-style dashboard built with React, Vite, Tailwind CSS,
Framer Motion, Lucide icons, and a fully procedural Web Audio sound engine.

## Run it

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

To build a static production bundle:

```bash
npm run build
npm run preview
```

## What's inside

- **Window chrome** — `src/components/TitleBar.jsx` + `src/App.jsx` drive a
  Mac-style traffic-light window with real minimize / maximize / close state,
  animated with Framer Motion. Minimizing tucks the window into a boba-themed
  dock at the bottom (`src/components/Dock.jsx`); closing plays a soft
  "shop's closed" sequence with a Reopen button.
- **Sound engine** — `src/utils/soundManager.js` synthesizes every click,
  hover, minimize (two sequential pearl pops), maximize, and the descending
  "sad pop" close sound directly with the Web Audio API — no audio files.
- **Weather** — `src/components/WeatherWidget.jsx` calls the free, key-free
  Open-Meteo API using the browser's geolocation (falls back to a default
  city if permission is denied), and layers boba-themed copy on top of the
  real temperature/condition.
- **Clock** — `src/components/ClockWidget.jsx` is a live analog "café timer"
  face plus a digital readout and mini week strip.
- **Hardware monitor** — `src/components/HardwareMonitor.jsx` simulates
  CPU / GPU / RAM as liquid-filling "boba tanks" with floating pearls.
- **Mini arcade** — `src/components/ArcadeSection.jsx` tabs between two
  playable games:
  - **Catch the Boba** (`games/CatchBobaGame.jsx`) — steer a cup with the
    mouse or arrow keys to catch falling pearls before time runs out.
  - **Tea Merge** (`games/TeaMerge2048.jsx`) — a 2048 clone where tea
    flavors (Water → Milk Tea → Taro → Matcha → … → Legendary Boba) merge
    as you slide tiles with the arrow keys or swipes.

- **Username system** — `src/components/LoginScreen.jsx` greets first-time
  visitors, asks for a name and a boba-cup color, and saves it to
  `localStorage`. Returning visitors skip straight to the dashboard with a
  time-of-day greeting ("Good afternoon, Alex 🧋"). The avatar chip in the
  title bar (`ProfileMenu.jsx`) offers "Switch user" to log out and hand the
  device to someone else.
- **"About This Café" device panel** — `src/components/DeviceInfo.jsx` +
  `src/utils/device.js` detect and display what you're actually using it on
  (iPad / iPhone / Android / desktop), OS, browser, touch vs. mouse input,
  screen size, pixel density, and orientation — live-updating on resize or
  rotation.

## Progressive Web App (PWA)

BobaOS installs like a real app — on desktop, Android, and iPad/iPhone.

- Powered by `vite-plugin-pwa` (already in `package.json` — installs with
  `npm install`, no extra setup).
- **Web app manifest** (`vite.config.js`) with the generated boba-cup icon
  set in `public/icons/` (192px, 512px, and a maskable variant for
  Android's adaptive icon shapes), `display: "standalone"` so it opens
  without browser chrome, and matching theme/background colors.
- **Offline support** via a Workbox-generated service worker that
  precaches the app shell, so it opens even with no connection. The
  weather widget uses a network-first strategy so it stays live when
  online but won't hard-fail offline; Google Fonts are cached long-term.
- **In-app install**: a persistent **Install** button lives in the title
  bar at all times (`src/components/TitleBar.jsx`, driven by
  `src/utils/useInstallPrompt.js`). On Chrome/Edge/desktop/Android it
  triggers the real browser install dialog directly; on iPad/iPhone Safari
  (which has no install API) or an unsupported browser, it opens a small
  banner with the right instructions instead. Once installed, the button
  turns into an "Installed" badge. There's also an auto-surfacing dismissible
  banner (`src/components/InstallPrompt.jsx`) the first time installing
  becomes available, for people who miss the button.
- Test installability locally with `npm run build && npm run preview`
  (service workers generally don't run reliably from `npm run dev` in
  most browsers, though `devOptions.enabled: true` is set so it will
  attempt to in dev too).

## Deploying to GitHub Pages

A workflow is already set up at `.github/workflows/deploy.yml`, and
`vite.config.js` uses a relative `base: './'` (and a relative PWA
`start_url`/`scope`) so the build works correctly from a project subpath
like `https://<you>.github.io/<repo>/` — no need to edit anything for your
specific repo name.

1. Push this project to a GitHub repository (see below if you haven't yet).
2. In the repo, go to **Settings → Pages**, and under "Build and deployment
   → Source", choose **GitHub Actions**.
3. Push to `main` (or run the workflow manually from the **Actions** tab).
   It builds the app and deploys `dist/` automatically.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/`
   — GitHub shows the exact URL on the Pages settings screen and in the
   workflow run summary once it succeeds.

Pushing to GitHub, if you haven't already:

```bash
cd boba-desktop
git init
git add .
git commit -m "Initial commit: BobaOS dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

Since GitHub Pages serves over HTTPS, the install button and offline
support both work correctly once it's live there.

## iPad & phone support

- The window auto-fills the screen on compact viewports (width ≤ 900px or
  height ≤ 520px) instead of trying to render the 960×640 desktop window.
- Both mini-games render at a fixed internal resolution but are scaled down
  responsively (via a measured-container + CSS transform) so they fit
  phone widths without ever overflowing or requiring horizontal scrolling.
- Traffic-light window controls and other tap targets are sized for touch,
  `touch-action: manipulation` avoids double-tap zoom, `100dvh` handles
  mobile Safari's shifting viewport, and `env(safe-area-inset-*)` keeps
  content clear of notches / home indicators.
- Add it to the iPad/iPhone home screen (Share → Add to Home Screen) for a
  standalone, fullscreen "app" feel — the meta tags for that are already set.

## Notes

- Browsers require a user gesture before audio can play — sound kicks in
  as soon as you click anything (this is standard Web Audio behavior, not
  a bug).
- The weather widget will ask for location permission; deny it and it
  quietly falls back to a default city.
- The username is stored only in the browser's own `localStorage` — there's
  no backend, so it's local to that device/browser.
- `prefers-reduced-motion` is respected globally.
